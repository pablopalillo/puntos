XCloner is the further development of the original JoomlaCloner backup component

Beside the main features of the original component, we have added native support for Joomla 1.5 through the automatic installer

XCloner is also able to run standalone, and it can be used now to backup also non-Joomla sites

General Install Instructions:

1. upload the archive file in your site root in a directory called xcloner/ for example
2. after you decided what the backup root path would be from where XCloner will pull the file structure, you
will need to create in that root path this directory administrator/backups and make it writeable
3. make sure you login to XCloner Configuration and check the Info tab for further clarifications on your required configuration

For Joomla1.5:
 
 - all you need to do is Install the component as a native component and access it from the Components Menu

For Joomla 1.0.x:

 - you won't be able to install the component as a native component for Joomla 1.0.x system, however you can follow the
steps from the General Install Instructions: area with one change, upload the component files in a directory 
called administrator/component/com_xcloner and access it as http://mysite/administrator/component/com_xcloner

For further clarifications or support please access the JoomlaPlug.com site

Translation credits:
- dutch = GhostDivision


