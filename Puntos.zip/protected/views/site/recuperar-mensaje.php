<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle= 'Recuperar contraseña - ' .Yii::app()->name;
?>

<div id="recuperar">

	<header>
		<div id="titulo-recuperar">
			<h1>Recuperar contraseña</h1>
		</div>
	</header>

		<div class="col-sm-5">
			<div class="well">
		 			<?php echo $mensaje; ?>
			</div>
		</div>

</div>
