<?php
/* @var $this SiteController */

$this->pageTitle = Yii::app()->name;
?>
<div id="content">

	</div>
	<div id="left-content">
		<iframe width="560" height="420" src="http://www.youtube.com/embed/AWf5fv51Vo8" frameborder="0" allowfullscreen></iframe>
	</div>

</div>
