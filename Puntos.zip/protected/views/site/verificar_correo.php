
<div id="content" class="row">
  <div class="ctn_contenido verificar-correo">
    <h2><?php echo '<p>Hola ' . strtok($datos['nombre'], ' ') . '</p>'; ?></h2>
    <p>Estás cerca iniciar el juego para participar por el viaje a Suiza gracias los Juegos Olímpicos de la Juventud Medellín 2018. Revisa tu correo electrónico para poder continuar.</p>
    <p>No olvides que al correo electrónico del adulto que inscribiste también llegará un mensaje.</p>
  </div>
</div>
