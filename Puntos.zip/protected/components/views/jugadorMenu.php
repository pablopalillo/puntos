<?php $usuario = $this->getUsuario(); ?>
<div>
	<p>Puntaje</p>
	<p>Puntaje total: <?php echo $usuario->jugadors[0]->puntaje; ?></p>
</div>