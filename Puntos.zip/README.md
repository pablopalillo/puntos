# puntos
Sistema de puntos para telemedellín, funciona como una trivia de preguntas aleatoreas.

. Se puede adaptar a sistemas de trivias , con intentos , puntos y dificultades
. esta hecho con framework yii y bootstrap-

